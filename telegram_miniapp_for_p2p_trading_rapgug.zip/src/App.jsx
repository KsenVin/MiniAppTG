import React from 'react';
import ChatList from './components/ChatList';
import SearchBar from './components/SearchBar';
import './App.css'

function App() {
  return (
    <div className="app">
      <SearchBar />
      <ChatList />
    </div>
  );
}

export default App;
