import React from 'react';

function ChatItem({ chat }) {
  return (
    <div className="chat-item">
      <img src={chat.avatar} alt="Avatar" className="avatar" />
      <div className="chat-info">
        <div className="name-time">
          <span className="name">{chat.name}</span>
          <span className="time">{chat.time}</span>
        </div>
        <div className="last-message">
          <p>{chat.lastMessage}</p> <span className='unread'>{chat.unread > 0 && chat.unread}</span>
        </div>
      </div> <span className='date'>{chat.date}</span>
    </div>
  );
}

export default ChatItem;
