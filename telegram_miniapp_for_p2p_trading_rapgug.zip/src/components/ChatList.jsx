import React from 'react';
import ChatItem from './ChatItem';

const placeholderData = [
  { name: 'Marcin Kowalski', lastMessage: 'Hey there!', time: '08:40', date: '02 Mar', online: true, unread:3, avatar: 'https://via.placeholder.com/50' },
  { name: 'Bożenna Malina', lastMessage: 'How are you?', time: '12:30', date: 'Today', online: false, unread: 0, avatar: 'https://via.placeholder.com/50' },
  { name: 'Odbast Pietrowski', lastMessage: 'Okay, super', time: '15:15', date: '18 Mar', online: true, unread: 0, avatar: 'https://via.placeholder.com/50' },
  { name: 'Krysia Eurydyka', lastMessage: 'Will do, thanks!', time: '18:00', date: '14 Mar', online: false, unread: 5, avatar: 'https://via.placeholder.com/50' },
  { name: 'Marcin Dróźdźewski', lastMessage: 'No problem!', time: '20:50', date: 'Yesterday', online: true, unread: 0, avatar: 'https://via.placeholder.com/50' },
];

function ChatList() {
  return (
    <div className="chat-list">
      {placeholderData.map((chat, index) => (
        <ChatItem key={index} chat={chat} />
      ))}
    </div>
  );
}

export default ChatList;
