import { create } from 'zustand';
import { User, Order } from '../types';

interface Store {
  user: User | null;
  orders: Order[];
  setUser: (user: User | null) => void;
  addOrder: (order: Order) => void;
  updateOrder: (orderId: number, updates: Partial<Order>) => void;
}

export const useStore = create<Store>((set) => ({
  user: null,
  orders: [],
  setUser: (user) => set({ user }),
  addOrder: (order) => set((state) => ({ orders: [...state.orders, order] })),
  updateOrder: (orderId, updates) =>
    set((state) => ({
      orders: state.orders.map((order) =>
        order.id === orderId ? { ...order, ...updates } : order
      ),
    })),
}));