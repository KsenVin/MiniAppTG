import React, { useEffect, useState } from 'react';
import { WebApp } from '@twa-dev/sdk';
import { Coins, TrendingUp, UserCircle, Shield, Zap, DollarSign } from 'lucide-react';
import { useStore } from './store/useStore';
import { TradeForm } from './components/TradeForm';
import { OrderList } from './components/OrderList';

function App() {
  const [activeTab, setActiveTab] = useState<'market' | 'trade' | 'profile'>('market');
  const [tradeType, setTradeType] = useState<'buy' | 'sell'>('buy');

  useEffect(() => {
    try {
      if (window.Telegram?.WebApp) {
        WebApp.ready();
        const initUser = {
          id: WebApp.initDataUnsafe?.user?.id || 0,
          username: WebApp.initDataUnsafe?.user?.username || 'Guest',
          subscriptionLevel: 'basic'
        };
        useStore.getState().setUser(initUser);
      }
    } catch (error) {
      console.error('Failed to initialize Telegram WebApp:', error);
    }
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'market':
        return (
          <>
            <section className="mb-6">
              <div className="bg-[#1E293B] rounded-lg p-4">
                <h1 className="text-2xl font-bold text-center mb-4 text-yellow-400">
                  Нужна валюта в R2Online? Мы знаем, где её взять!
                </h1>
                <p className="text-gray-300 mb-6 text-center">
                  Не теряйте время на поиски лучшего курса. Наш бот готов предложить вам серебро по самой выгодной цене прямо сейчас. Обменяйте и наслаждайтесь игрой!
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-[#2D3748] p-4 rounded-lg flex items-center">
                    <DollarSign className="w-8 h-8 text-green-400 mr-3" />
                    <div>
                      <h3 className="font-semibold">Выгодные цены</h3>
                      <p className="text-sm text-gray-400">на покупку и продажу</p>
                    </div>
                  </div>
                  <div className="bg-[#2D3748] p-4 rounded-lg flex items-center">
                    <Shield className="w-8 h-8 text-blue-400 mr-3" />
                    <div>
                      <h3 className="font-semibold">Безопасность</h3>
                      <p className="text-sm text-gray-400">гарантия всех сделок</p>
                    </div>
                  </div>
                  <div className="bg-[#2D3748] p-4 rounded-lg flex items-center">
                    <Zap className="w-8 h-8 text-yellow-400 mr-3" />
                    <div>
                      <h3 className="font-semibold">Мгновенно</h3>
                      <p className="text-sm text-gray-400">без комиссий</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            <section className="mb-6">
              <div className="bg-[#1E293B] rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold">Текущий Рынок</h2>
                  <TrendingUp className="w-5 h-5 text-green-400" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-[#2D3748] p-3 rounded-lg">
                    <p className="text-sm text-gray-400">Текущая цена</p>
                    <p className="text-xl font-bold">1,250,000</p>
                  </div>
                  <div className="bg-[#2D3748] p-3 rounded-lg">
                    <p className="text-sm text-gray-400">Объем за 24ч</p>
                    <p className="text-xl font-bold">15.2M</p>
                  </div>
                </div>
              </div>
            </section>
            <section className="mb-6">
              <div className="bg-[#1E293B] rounded-lg p-4">
                <h2 className="text-lg font-semibold mb-4">Активные ордера</h2>
                <OrderList />
              </div>
            </section>
          </>
        );
      case 'trade':
        return (
          <div className="bg-[#1E293B] rounded-lg p-4">
            <div className="flex gap-2 mb-4">
              <button
                className={`flex-1 py-2 px-4 rounded-lg font-medium ${
                  tradeType === 'buy'
                    ? 'bg-green-500'
                    : 'bg-[#2D3748] text-gray-300'
                }`}
                onClick={() => setTradeType('buy')}
              >
                Купить
              </button>
              <button
                className={`flex-1 py-2 px-4 rounded-lg font-medium ${
                  tradeType === 'sell'
                    ? 'bg-red-500'
                    : 'bg-[#2D3748] text-gray-300'
                }`}
                onClick={() => setTradeType('sell')}
              >
                Продать
              </button>
            </div>
            <TradeForm type={tradeType} />
          </div>
        );
      case 'profile':
        return (
          <div className="bg-[#1E293B] rounded-lg p-4">
            <h2 className="text-lg font-semibold mb-4">Ваш Профиль</h2>
            <div className="space-y-4">
              <div className="bg-[#2D3748] p-3 rounded-lg">
                <p className="text-sm text-gray-400">Имя пользователя</p>
                <p className="text-xl font-bold">{useStore.getState().user?.username}</p>
              </div>
              <div className="bg-[#2D3748] p-3 rounded-lg">
                <p className="text-sm text-gray-400">Уровень подписки</p>
                <p className="text-xl font-bold capitalize">
                  {useStore.getState().user?.subscriptionLevel}
                </p>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#0F172A] text-white">
      <header className="bg-[#1E293B] p-4 fixed top-0 w-full z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Coins className="w-6 h-6 text-yellow-400" />
            <h1 className="text-xl font-bold">R2Online Trading</h1>
          </div>
          <UserCircle className="w-6 h-6" />
        </div>
      </header>

      <main className="pt-16 pb-20 px-4">
        {renderContent()}
      </main>

      <nav className="fixed bottom-0 w-full bg-[#1E293B] border-t border-[#2D3748]">
        <div className="flex justify-around p-4">
          <button
            className={`flex flex-col items-center text-sm ${
              activeTab === 'market' ? 'text-blue-400' : ''
            }`}
            onClick={() => setActiveTab('market')}
          >
            <TrendingUp className="w-6 h-6 mb-1" />
            Рынок
          </button>
          <button
            className={`flex flex-col items-center text-sm ${
              activeTab === 'trade' ? 'text-blue-400' : ''
            }`}
            onClick={() => setActiveTab('trade')}
          >
            <Coins className="w-6 h-6 mb-1" />
            Торговля
          </button>
          <button
            className={`flex flex-col items-center text-sm ${
              activeTab === 'profile' ? 'text-blue-400' : ''
            }`}
            onClick={() => setActiveTab('profile')}
          >
            <UserCircle className="w-6 h-6 mb-1" />
            Профиль
          </button>
        </div>
      </nav>
    </div>
  );
}

export default App;