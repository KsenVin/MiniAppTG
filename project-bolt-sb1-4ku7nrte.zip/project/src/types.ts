export interface User {
  id: number;
  username: string;
  subscriptionLevel: 'basic' | 'premium' | 'vip';
}

export interface Order {
  id: number;
  type: 'buy' | 'sell';
  amount: number;
  price: number;
  createdBy: number;
  status: 'active' | 'completed' | 'cancelled';
  createdAt: string;
}