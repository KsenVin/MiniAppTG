import React, { useState } from 'react';
import { useStore } from '../store/useStore';

interface TradeFormProps {
  type: 'buy' | 'sell';
}

export function TradeForm({ type }: TradeFormProps) {
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState('');
  const { user, addOrder } = useStore();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const newOrder = {
      id: Date.now(),
      type,
      amount: Number(amount),
      price: Number(price),
      createdBy: user.id,
      status: 'active' as const,
      createdAt: new Date().toISOString()
    };

    addOrder(newOrder);
    setAmount('');
    setPrice('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-1">
          Amount (Silver)
        </label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="w-full bg-[#2D3748] rounded-lg p-2 text-white"
          placeholder="Enter amount"
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-1">
          Price (per 1M)
        </label>
        <input
          type="number"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          className="w-full bg-[#2D3748] rounded-lg p-2 text-white"
          placeholder="Enter price"
          required
        />
      </div>
      <button
        type="submit"
        className={`w-full py-2 px-4 rounded-lg font-medium ${
          type === 'buy'
            ? 'bg-green-500 hover:bg-green-600'
            : 'bg-red-500 hover:bg-red-600'
        }`}
      >
        Place {type === 'buy' ? 'Buy' : 'Sell'} Order
      </button>
    </form>
  );
}