import React from 'react';
import { useStore } from '../store/useStore';
import { Order } from '../types';

export function OrderList() {
  const { orders, user } = useStore();

  const sortedOrders = [...orders].sort((a, b) => {
    if (a.type === 'sell' && b.type === 'buy') return -1;
    if (a.type === 'buy' && b.type === 'sell') return 1;
    return a.price - b.price;
  });

  const formatAmount = (amount: number) => {
    return amount >= 1000000
      ? `${(amount / 1000000).toFixed(1)}M`
      : amount.toLocaleString();
  };

  const isUserOrder = (order: Order) => order.createdBy === user?.id;

  return (
    <div className="space-y-2">
      {sortedOrders.map((order) => (
        <div
          key={order.id}
          className={`bg-[#2D3748] p-3 rounded-lg flex justify-between items-center ${
            isUserOrder(order) ? 'border border-blue-500' : ''
          }`}
        >
          <span
            className={order.type === 'buy' ? 'text-green-400' : 'text-red-400'}
          >
            {order.type.toUpperCase()}
          </span>
          <span>{formatAmount(order.amount)}</span>
          <span>{order.price.toLocaleString()}</span>
          {isUserOrder(order) && (
            <span className="text-xs text-blue-400">Your Order</span>
          )}
        </div>
      ))}
    </div>
  );
}